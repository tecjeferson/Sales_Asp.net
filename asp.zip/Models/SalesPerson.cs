

namespace aspnetapp.Models
{
    public class SalesPerson
    {

        public int SalesPersonId { get; set; }
        public string Salesperson { get; set; }
    }
}