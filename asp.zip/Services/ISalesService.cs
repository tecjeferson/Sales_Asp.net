using System.Collections.Generic;
using aspnetapp.Models;

namespace aspnet.Services
{
    public interface ISalesService
    {
        Sales Create(Sales sales);
        Sales FindById(int id);
        List<Sales> FindAll();
        Sales Update(Sales sales);
        void Delete(int id);
    }
}