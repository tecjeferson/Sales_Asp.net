using System.Collections.Generic;
using aspnetapp.Models;

namespace aspnet.Services
{
    public interface ISalesPersonService
    {
        SalesPerson Create(SalesPerson salesperson);
        SalesPerson FindById(int id);
        List<SalesPerson> FindAll();
        SalesPerson Update(SalesPerson salesperson);
        void Delete(int id);

    }
}